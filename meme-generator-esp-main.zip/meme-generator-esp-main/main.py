from flask import Flask, render_template, request, send_from_directory

app = Flask(__name__)

@app.route('/', methods=['GET','POST'])
def index():
    if request.method == 'POST':
        selected_image = request.form.get('image-selector')
        Selected_color = request.form.get("textcolor")
        InfColor=request.form.get("textcolorInf")
        textosup = request.form.get("principal")
        textosinf = request.form.get("inferior")

        superiorY = request.form.get("superiorY")
        inferiorY = request.form.get("inferiorY")

        return render_template(
            'index.html',
            selected_image=selected_image,

            textSup=textosup or "",
            textoInf=textosinf or "",

            Selected_Color=Selected_color or "white",
            InfColor=InfColor,
            SupY=superiorY or 0,
            InfY=inferiorY or 0,
        )
    else:
        return render_template(
            'index.html',
            selected_image='logo.svg',
            textSup="",
            textoInf="",
            Selected_Color="white",
            InfColor="white",
            SupY=0,
            InfY=0
        )

@app.route('/static/img/<path:path>')
def serve_images(path):
    return send_from_directory('static/img', path)

app.run(debug=True)